////////////////////////
/// Made by Team AOF ///
////////////////////////

onEvent('recipes', (event) => {

  
    event.custom({    
        "type": "modern_industrialization:macerator",
        "id": "aof:mi_macerator_pervaded_netherrack",
        "eu": 2,
        "duration": 100,
        "item_inputs": [
          {
            "item": "byg:pervaded_netherrack",
            "amount": 1
          }
        ],
        "item_outputs": [
          {
            "item": "minecraft:glowstone_dust",
            "amount": 2
          }
        ]
})
    })