

////////////////////////
/// Made by Team AOF ///
////////////////////////


onEvent('recipes', (event) => {

  // Dwarf Charcoal
  event.shapeless('8x dwarfcoal:dwarf_charcoal', ['minecraft:charcoal']);
  
});
