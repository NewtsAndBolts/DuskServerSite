////////////////////////
/// Made by Team AOF ///
////////////////////////

onEvent('recipes', (event) => {

  // Chisel
  event.shaped('chisel:chisel', [
    ["minecraft:stick", null, null],
    [null, "minecraft:iron_ingot", null],
    [null, null, null],
  ]);

});
