onEvent('item.registry', event => {

	event.create('aof5_logo').displayName('AOF5 Logo')
});